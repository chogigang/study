#include <stdio.h>
#include<iostream>
using namespace std;


// 1-1
//  섭씨 화씨  예제
//int main(){
//    char ch; //문자 입력받는 용
//    float input ,output;
//    
//    cout<<"화씨를 입력할경우 F,f  섭씨를 입력할경우 C,c를 입력하세요:";
//    cin>>ch;
//    
//    cout<<"온도를 입력하세요 : ";
//    cin >>input;
//    
//    if(ch == 'f' || ch =='F'){
//        output = (5.0/9.0)*(input-32);
//        cout<<"화씨: "<<input<<"\n변환된 섭씨: "<<output<<"\n";
//        
//
//    }else if(ch=='c'||ch =='C'){
//        output = (9.0/5.0)*input+32;
//        cout<<"섭씨:"<<input<<"\n 변환된 화씨: "<<output<<"\n";
//        
//    }else{
//        cout<<"잘못된 출력입니다.";
//    }
//}


// 1-2
// 스위치 케이스 문을 사용한 섭씨 화씨
//int main(){
//    
//    char ch;
//    int input,output;
//    
//    cout<<"화씨를 입력할경우 F,f 섭씨를 입력할 경우 C,c를 입력하세요: ";
//    cin>> ch;
//    
//    cout<<"온도를 입력하세요: ";
//    cin>>input;
//    
//    
//    switch (ch) {
//        case 'c':
//        case 'C':
//            output = (9.0/5.0)*input+32;
//            cout<<"섭씨: "<<input<<"\n변환된 화씨: "<<output<<"\n";
//            break;
//        case 'f':
//        case 'F':
//            output = (5.0/9.0)*(input-32);
//            cout<<"화씨: "<<input<<"\n변환된 섭씨: "<<output<<"\n";
//            break;
//      
//        default:
//            cout<<"잘못된 출력입니다.\n";
//            break;
//    }
//    
//    
//}

//1-3
//  5개의 정수를 입력 받아 *를 이용하여 작성하시오
//함수없이
//int main() {
//    int input[5] = { 0,0,0,0,0 };
//    cout << "다섯개의 정수를 입력하세요 :";
//    for (int i = 0; i < 5; i++) {
//       // cout << "다섯개의 정수를 입력하세요 :";
//        cin >> input[i];
//   
//    }
//    
// 
//    for(int i=0;i<5; i++){
//      int count =input[i];
//        cout<<"번호"<<i;
//        for(int j=0; j<count;j++){
//            cout<<'*';
//        }
//        cout<<"\n";
//    }
//
//}

// 함수 로 나눠서 작성
void input(int inputarr[5]){
    cout << "다섯개의 정수를 입력하세요 :";
    for (int i = 0; i < 5; i++) {

           cin >> inputarr[i];
    }
}

void output(int inputarr[5]){
    for(int i=0;i<5.; i++){
        int count =inputarr[i];
          cout<<"번호"<<i;
          for(int j=0; j<count;j++){
              cout<<'*';
          }
          cout<<"\n";
      }
}

int main(){
    int inputarr[5]={0,0,0,0,0};

    input(inputarr);
    output(inputarr);

}


/*
 3번 *문제에서 입력하라는 문자를  5번이 출력하는 것을 선택을 할지 고민하다 스크린샷 문제에 출력할 당시 동시에 4 15 2 7 스페이스바를 이용해 한번에 배열에 입력하는것을 보고 수정했습니다.
 */
